
            app.impData = xlsread('ja.xls', 'Hyst. data', 'A:B');
            [row, col] = size(app.impData);
            app.numImpRows = row; 
            
            temp = app.impData(1,1);
            lop=0;
            for i = 2:1:app.numImpRows
               % if (temp ~= app.impData(i,1)) 
               if (temp == app.impData(i,1)) 
                   % if isnan(app.impData(i,1))
                        %nothing
                     %  else
                          % temp = temp + 1;
                         lop=lop+1;
                   % end
                    
                end
            end
            
            msg = 'There are %d measured loops available in the imported file.\n\nSelect maximum 4 loops.\n\nHold ctrl and click to select.\n\nYou have selected: ';
            %app.msgNumMeas = sprintf(msg,temp);
            app.msgNumMeas = sprintf(msg,lop);
            msg = 'There are %d measured loops available in the imported file.\n\nSelect maximum 4 loops.\n\nHold ctrl and click to select.\n\nYou have selected: 1';
            %app.taInstructions.Value = sprintf(msg,temp);
            app.taInstructions.Value = sprintf(msg,lop);