# JAMPS
Software for determining the Jiles-Atherton parameters based on measured H-B loops.
