%% JA模型粒子群算法
clear;clc
close all
%% 加载数据
%-------------------------%%%%%%%%%%%%%%%-%%%%%%%%%%%%%%%%----------0.5T------%%%%%%%%%%%%%%%%%%----------------%%%%%%%%%
% data=xlsread("D:\BaiduSyncdisk\paper\2\实验文档\实验数据\K101_-50℃\K101_-50℃_0.5T\K101_-50℃_0.5T_10Hz.xlsx"); %-50
% data=xlsread("D:\BaiduSyncdisk\paper\2\实验文档\实验数据\K101_0℃\K101_0℃_0.5T\K101_0℃_0.5T_10Hz.xlsx");  %0
% data=xlsread("D:\BaiduSyncdisk\paper\2\实验文档\实验数据\K101_25℃\K101_0.5T_25℃\K101_0.5T_25℃_10Hz_0.01532.xlsx"); %25
% data=xlsread("D:\BaiduSyncdisk\paper\2\实验文档\实验数据\K101_50℃\k101_50℃_0.5T\K101_50℃_0.5T_10HZ.xlsx"); %50
data=xlsread("D:\BaiduSyncdisk\paper\5.Procedures\10.17\10.17\新建 Microsoft Excel 工作表.xlsx");

% data=cell2mat(struct2cell(load("test2.mat")));
%--------------------%%%%%%%%%%%%----------------%%%%%%%%%%%%%%%%%-----------------%%%%%%%%%%%%%%%%%------------%
u0=4*pi*10^-7;

H=data(:,1);

Breal=data(:,2);
hold on 
% plot(H,Breal,"r-");
% N=5;
% for i=1:N
%     Breal=smooth(Breal);
%     H=smooth(H);
% end
% plot(H,Breal,"b-");
hold off;

M=Breal/u0-H;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
a=3.794046e+02;	k=1.102153e+02;	c=1.095524e-01;	alpha=3.809336e-04;	Ms=1.395607e+06;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gbest=[a k c Ms alpha];
%% 多次循环

CycleNumber = 5;  % 按需增加

for z=1:CycleNumber
%% 预设参数

n = 100; %粒子数量
d = 5;   %变量个数
c1 = 2;
c2 = 2;
w = 0.9;
K = 200; %迭代次数

%%  分布粒子

v = zeros(n,d);
x = zeros(n,d);
x(1:n-1,1) = a*1.5*rand(n-1,1);
x(1:n-1,2) = k*2*rand(n-1,1);
x(1:n-1,3) = abs(c)*2*rand(n-1,1);
x(1:n-1,4) = Ms*2*rand(n-1,1);
x(1:n-1,5) = alpha*2*rand(n-1,1);
x(n,:)=gbest;


%% 计算适应度

fit = zeros(n,1);
for j = 1:n
    
    M0=Breal(1)/(4*pi*1e-7)-H(1);
    fit(j) = JAFitnessFun(x(j,:),H,M0,Breal);

end
pbest = x;
ind = find(min(fit) == fit);
gbest = x(ind,:);

%% 更新速度与位置
for i = 1:K
    % 更新速度与位置
    for m = 1:n
        v(m,:) = w*v(m,:) + c1*rand*(pbest(m,:) - x(m,:)) + c2*rand*(gbest - x(m,:));

%         for j = 1: d
%             if v(m,j) < Lbx(j)
%                 v(m,j) = Lbx(j);
%             elseif v(m,j) > Ubx(j)
%                 v(m,j) = Ubx(j);
%             end
%         end
        
        x(m,:) = x(m,:) + v(m,:);

%         for j = 1: d
%             if x(m,j) < Lbx(j)
%                 x(m,j) = Lbx(j);
%             elseif x(m,j) > Ubx(j)
%                 x(m,j) = Ubx(j);
%             end
%         end

        % 重新计算适应度
        fit(m) = JAFitnessFun(x(m,:),H,M0,Breal);
        if fit(m) < JAFitnessFun(pbest(m,:),H,M0,Breal)
            pbest(m,:) = x(m,:);
        end
        if  JAFitnessFun(pbest(m,:),H,M0,Breal) < JAFitnessFun(gbest,H,M0,Breal)
            gbest = pbest(m,:);
        end
    end
    fitnessbest((z-1)*K+i) = JAFitnessFun(gbest,H,M0,Breal);
end

[Hmodel,Bmodel] = JAsingle_loop(gbest(1),gbest(2),gbest(3),gbest(4),gbest(5),H,M0);

a=gbest(1);  k=gbest(2);  c=gbest(3);  Ms=gbest(4);  alpha=gbest(5);  

clc;fprintf("当前已完成%f个周期",z);
end

fprintf('参数辨识值: \na=%e;  k=%e;  c=%e;  Ms=%e;  alpha=%e; \n\n',gbest);

figure(1)
hold on
plot(H,Breal,"r-",'LineWidth',2);
fprintf("试验损耗结果:%f\n",polyarea(H,Breal))
plot(H,Bmodel,"bo","LineWidth",2);
% set(gca,'linewidth',0.5)
fprintf("模型计算损耗结果:%f\n",polyarea(H,Bmodel))

hold off;
%坐标轴
box on;
%修改边框

xlabel('H (A/m)','fontsize',10);ylabel('B (T)','fontsize',10);
% set(gca,'FontWeight','bold');
set(gca,'FontName','Times');

% xlim([-15,15]);ylim([-0.6,0.6]);
% xticks(-15:5:15);yticks(-0.5:0.2:0.5);
set(gca,'FontSize',10);
set(gca,'FontWeight','bold');
set(gca,'FontName','Times');
%  网格
grid on;
set(gca, 'GridLineStyle', '--');  % 设置为虚线
set(gca, 'GridAlpha', 1);  % 设置透明度，注意参数的范围是[0,1]
%图例
legend('boxoff');
lg1=legend('Simulated loops','Measured loops');
set(lg1,'FontSize',10,'FontName','Times','FontWeight','bold');
set(lg1,'Location','northwest');
%设置输出的图的大小
set(gcf,'PaperUnits','centimeters')
set(gcf,'PaperSize',[28,11.4])
set(gcf,'PaperPositionMode','manual')
set(gcf,'PaperPosition',[0,0,28,11.4]);
set(gcf,'Renderer','painters');



fprintf("模型计算相对误差%f %",abs(polyarea(H,Bmodel)-polyarea(H,Breal))/polyarea(H,Breal)*100);
figure(2);plot(fitnessbest,'-');hold on
xlabel('迭代次数','fontsize',15);ylabel('适应度值','fontsize',15);
legend('粒子群算法');


