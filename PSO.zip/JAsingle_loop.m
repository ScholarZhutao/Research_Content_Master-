function [Hm,Bs] = JAsingle_loop(a,k,c,Ms,alpha,Hm,M0_)
mu0=4*pi*10^-7;
Bs=zeros(size(Hm));
M=zeros(size(Hm));
M(1)=M0_;
Bs(1)=(M(1)+Hm(1))*mu0;
    for i=2:size(Hm,1)
        dH=Hm(i)-Hm(i-1);
        delta=sign(dH);
        He=Hm(i-1)+alpha*M(i-1);
        Man=Ms*(coth((He)/a)-a/(He));
        deltaM = (sign(delta*sign(Man-M(i-1)))+1)/2;
        dMan_dHe = Ms/a*(1-(coth(He/a))^2+(a/He)^2);
        fenzi = deltaM*(Man-M(i-1))+k*delta*c*dMan_dHe;
        fenmu = (k*delta-deltaM*(Man-M(i-1))*alpha-k*delta*alpha*c*dMan_dHe);
        dMdH = fenzi/fenmu;
        M(i)=M(i-1)+dMdH*dH;
        Bs(i)=mu0*(Hm(i)+M(i));
    end


end