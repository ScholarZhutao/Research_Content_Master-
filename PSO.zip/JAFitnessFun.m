%计算适应度函数
function y = JAFitnessFun(x,H,M0,Breal)


[~,Bmodel] = JAsingle_loop(x(1),x(2),x(3),x(4),x(5),H,M0); %根据辨识出的五个参数值计算磁感应强度B

y = sqrt(sum((Breal-Bmodel).^2)./size(H,1));                               %适应度函数

end